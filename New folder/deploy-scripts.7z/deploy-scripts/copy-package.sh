##Satveer Gaur
#!/bin/bash
# This script should deploy or build and deploy a given package

dat=$(date +"%m-%d-%y-%H-%M")

echo $dat
basename_artifact=`basename $1/*.zip`
echo $basename_artifact
basename_artifact1=`echo $basename_artifact|awk -F"zip" '{  print $1}'`
from=$1
to=$2

cp -arf "$from/$basename_artifact" "$to/"

