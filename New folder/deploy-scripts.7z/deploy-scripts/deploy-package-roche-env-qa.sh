##Satveer Gaur
#!/bin/sh
# This script should deploy or build and deploy a given package

help() {
 echo "parameters: hostname port package-path package-name"
}


case $1 in
--help | -h | -help | -hlep)
help
;;
*)
if [ `echo $@ | wc -w` -gt 2 ]
then
#Deleting the Old Packages
curl -k -u jenkins:'NH8ifa7CAfe#ac1' -F force=true  $1/crx/packmgr/service.jsp?cmd=uninst\&name=$3
sleep 5
curl -k -u jenkins:'NH8ifa7CAfe#ac1' -F force=true  $1/crx/packmgr/service.jsp?cmd=rm\&name=$3
sleep 5
#Uploading and Installing the new Package
curl -k -u jenkins:'NH8ifa7CAfe#ac1'  -F name=$3 -F file=@$2 -F force=true $1/crx/packmgr/service.jsp?cmd=upload --verbose
sleep 10
curl -k -u jenkins:'NH8ifa7CAfe#ac1' -F force=true  $1/crx/packmgr/service.jsp?cmd=inst\&name=$3
sleep 5
else
help
fi;;
esac

