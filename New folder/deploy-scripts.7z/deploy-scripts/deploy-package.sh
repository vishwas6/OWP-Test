##Satveer Gaur
#!/bin/sh
# This script should deploy or build and deploy a given package

help() {
 echo "parameters: hostname port package-path package-name"
}


case $1 in
--help | -h | -help | -hlep)
help
;;
*)
if [ `echo $@ | wc -w` -gt 3 ]
then
#Deleting the Old Packages
curl -u $5:$6 -F force=true  http://$1:$2/crx/packmgr/service.jsp?cmd=uninst\&name=$4
sleep 5
curl -u $5:$6 -F force=true  http://$1:$2/crx/packmgr/service.jsp?cmd=rm\&name=$4
sleep 5
curl -u $5:$6 -X DELETE http://$1:$2/etc/packages/roche
sleep 5
#Uploading and Installing the new Package
curl -u $5:$6  -F name=$4 -F file=@$3 -F force=true http://$1:$2/crx/packmgr/service.jsp?cmd=upload --verbose
sleep 10
curl -u $5:$6 -F force=true  http://$1:$2/crx/packmgr/service.jsp?cmd=inst\&name=$4
sleep 5
else
help
fi;;
esac

