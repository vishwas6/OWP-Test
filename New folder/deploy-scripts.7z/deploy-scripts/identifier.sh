#! /bin/bash
#@ Satveer Gaur
identifier=`cat /data/jenkins/build-area/deploy-scripts/identifier.txt`
identifier=`expr $identifier + 1`
echo $identifier > /data/jenkins/build-area/deploy-scripts/identifier.txt

